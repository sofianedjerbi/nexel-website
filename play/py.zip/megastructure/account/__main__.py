from .service import main

if __name__ == "__main__":       # (importing this file never starts the service)
    main()
